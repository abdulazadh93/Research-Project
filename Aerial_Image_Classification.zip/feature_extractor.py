from utils import CLASS_FOLDERS, make_dirs, resetRandom
import tqdm
import glob
import os
import h5py
import numpy as np


def get_inception_v3_model():
    from keras.applications.inception_v3 import InceptionV3
    from keras.layers import Input
    model = InceptionV3(include_top=False,
                        weights='weights/inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5',
                        input_tensor=Input(shape=(299, 299, 3)))
    return model


def extract_feature(img_p, model):
    from keras.preprocessing import image
    from keras.applications.inception_v3 import preprocess_input
    size = (299, 299, 3)
    img = image.load_img(img_p, target_size=size)
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    feature = model.predict(x)
    feat = feature.flatten()
    return feat


if __name__ == '__main__':
    resetRandom()
    data_path = 'Data/source/UCM'
    data_save_path = 'Data/features'
    make_dirs(data_save_path)
    feats_dict = {'inception_v3_features': []}
    labels = []
    iv3_model = get_inception_v3_model()
    for cls in CLASS_FOLDERS:
        for img_path in tqdm.tqdm(glob.glob(os.path.join(data_path, cls, '*.tif')),
                                  desc=f'Extracting Features For Class {cls}'):
            feats_dict['inception_v3_features'].append(extract_feature(img_path, iv3_model))
            labels.append(CLASS_FOLDERS.index(cls))
    for k, v in feats_dict.items():
        if v:
            h5f_data = h5py.File(os.path.join(data_save_path, '{0}.h5'.format(k)), 'w')
            h5f_data.create_dataset('features', data=np.array(v))
            h5f_data.close()
    h5f_data = h5py.File(os.path.join(data_save_path, 'labels.h5'), 'w')
    h5f_data.create_dataset('labels', data=np.array(labels))
    h5f_data.close()
