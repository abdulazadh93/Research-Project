import os
import pickle
import sys

from PyQt5.QtCore import Qt, QThreadPool
from PyQt5.QtGui import QFontDatabase, QFont, QIntValidator, QImage, QPixmap
from PyQt5.QtWidgets import (QDialog, QProgressBar, QApplication, QWidget, QComboBox, QVBoxLayout, QGroupBox,
                             QGridLayout, QLineEdit, QPushButton, QLabel, QFileDialog, QMessageBox, QScrollArea)

from feature_extractor import extract_feature, get_inception_v3_model
from utils import resetRandom, Worker, CLASS_NAMES


class Retinopathy(QWidget):
    def __init__(self):
        QWidget.__init__(self)
        self.setWindowTitle(' ')
        self.screen_size = app.primaryScreen().size()
        self.screen_width = self.screen_size.width()
        self.screen_height = self.screen_size.height()

        self.app_width = (self.screen_width // 100) * 100
        self.app_height = (self.screen_height // 100) * 94
        self.setGeometry(0, 0, self.app_width, self.app_height)

        self.fc_retina = QFontDatabase.addApplicationFont('assets/fonts/FiraCode-Retina.ttf')

        self.full_v_box = QVBoxLayout()
        self.top_h_box = QVBoxLayout()
        self.bottom_h_box = QVBoxLayout()
        self.full_v_box.addLayout(self.top_h_box)
        self.full_v_box.addLayout(self.bottom_h_box)

        self.gb_1 = QGroupBox('Input Data')
        self.gb_2 = QGroupBox('Results')

        self.gb_1.setFixedWidth(self.app_width)
        self.gb_1.setFixedHeight((self.app_height // 100) * 25)
        self.gb_1.setFont(QFont('FiraCode', 10, 0))
        self.grid_1 = QGridLayout()
        self.gb_1.setLayout(self.grid_1)

        self.ip_le = QLineEdit()
        self.ip_le.setValidator(QIntValidator())
        self.ip_le.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.grid_1.addWidget(self.ip_le, 0, 0, Qt.AlignCenter)

        self.ci_pb = QPushButton('Choose Input Image')
        self.ci_pb.setFont(QFont('FiraCode', 10, 1))
        self.ci_pb.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.ci_pb.clicked.connect(self.choose_input)
        self.grid_1.addWidget(self.ci_pb, 1, 0, Qt.AlignCenter)

        self.re_pb = QPushButton('Reset')
        self.re_pb.setFont(QFont('FiraCode', 10, 1))
        self.re_pb.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.re_pb.clicked.connect(self.reset)
        self.grid_1.addWidget(self.re_pb, 2, 0, Qt.AlignCenter)

        self.ex_fe_pb = QPushButton('Extract Inception V3 Features')
        self.ex_fe_pb.setFont(QFont('FiraCode', 10, 1))
        self.ex_fe_pb.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.ex_fe_pb.clicked.connect(self.fe_extract_thread)
        self.grid_1.addWidget(self.ex_fe_pb, 0, 1, Qt.AlignCenter)

        self.cls_combo = QComboBox()
        self.cls_combo.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.cls_combo.setEditable(True)
        le = self.cls_combo.lineEdit()
        le.setFont(QFont('FiraCode', 10, 2))
        le.setAlignment(Qt.AlignCenter)
        le.setReadOnly(True)
        self.grid_1.addWidget(self.cls_combo, 1, 1, Qt.AlignCenter)

        self.cls_pb = QPushButton('Classify')
        self.cls_pb.setFont(QFont('FiraCode', 10, 1))
        self.cls_pb.setFixedWidth((self.gb_1.width() // 100) * 40)
        self.cls_pb.clicked.connect(self.classify_thread)
        self.grid_1.addWidget(self.cls_pb, 2, 1, Qt.AlignCenter)

        self.gb_2.setFixedHeight((self.app_height // 100) * 75)
        self.gb_2.setFont(QFont('FiraCode', 10, 0))
        self.grid_2_scroll = QScrollArea()
        self.gb_2_v_box = QVBoxLayout()
        self.grid_2_widget = QWidget()
        self.grid_2 = QGridLayout(self.grid_2_widget)
        self.grid_2_scroll.setWidgetResizable(True)
        self.grid_2_scroll.setWidget(self.grid_2_widget)
        self.gb_2_v_box.addWidget(self.grid_2_scroll)
        self.gb_2_v_box.setContentsMargins(0, 0, 0, 0)
        self.gb_2.setLayout(self.gb_2_v_box)

        self.top_h_box.addWidget(self.gb_1)
        self.bottom_h_box.addWidget(self.gb_2)
        self.setLayout(self.full_v_box)
        self.disable()

        self._input_image_path = ''
        self._image_size = (512, 512)
        self.index = 0
        self.feature = None
        self.fe_data = None
        self.class_ = None
        self.load_screen = Loading()
        self.thread_pool = QThreadPool()
        self.class_ = None
        self.show()

    def add_image(self, im_path, title, f_size=False):
        image_lb = QLabel()
        image_lb.setFixedHeight(self._image_size[0])
        image_lb.setFixedWidth(self._image_size[1])
        image_lb.setScaledContents(True)
        image_lb.setStyleSheet('padding-top: 30px;')
        qimg = QImage(im_path)
        pixmap = QPixmap.fromImage(qimg)
        image_lb.setPixmap(pixmap)
        self.grid_2.addWidget(image_lb, 1, self.index, Qt.AlignCenter)
        txt_lb = QLabel(title)
        if f_size:
            txt_lb.setFont(QFont('FiraCode', 14, 0))
            txt_lb.setStyleSheet("border: 1px solid black;")
        self.grid_2.addWidget(txt_lb, 0, self.index, Qt.AlignCenter)
        self.index += 1

    def show_message_box(self, title, icon, msg):
        msg_box = QMessageBox(self)
        msg_box.setFont(QFont('FiraCode', 10, 1))
        msg_box.setWindowTitle(title)
        msg_box.setText(msg)
        msg_box.setIcon(icon)
        msg_box.setDefaultButton(QMessageBox.Ok)
        msg_box.setWindowModality(Qt.ApplicationModal)
        msg_box.exec_()

    def choose_input(self):
        self.reset()
        self._input_image_path, _ = QFileDialog.getOpenFileName(self,
                                                                caption="Choose Input Image", directory=".",
                                                                options=QFileDialog.DontUseNativeDialog,
                                                                filter="JPG Files (*.jpg);;"
                                                                       "BMP Files (*.bmp);;PNG Files (*.png);;")
        if os.path.isfile(self._input_image_path):
            self.ip_le.setText(self._input_image_path)
            self.add_image(self._input_image_path, 'Input Image')
            self.ex_fe_pb.setEnabled(True)
        else:
            self.show_message_box('InputImageError', QMessageBox.Critical, 'Choose valid image?')

    @staticmethod
    def clear_layout(layout):
        while layout.count() > 0:
            item = layout.takeAt(0)
            if not item:
                continue
            w = item.widget()
            if w:
                w.deleteLater()

    def fe_extract_thread(self):
        worker = Worker(self.fe_extract_runner)
        self.thread_pool.start(worker)
        worker.signals.finished.connect(self.fe_extract_finisher)
        self.load_screen.setWindowModality(Qt.ApplicationModal)
        self.load_screen.show()

    def fe_extract_runner(self, progress_callback):
        self.feature = extract_feature(self._input_image_path, get_inception_v3_model())
        progress_callback.emit('Done')

    def fe_extract_finisher(self):
        self.cls_combo.setEnabled(True)
        self.cls_pb.setEnabled(True)
        self.ex_fe_pb.setEnabled(False)
        self.load_screen.close()

    def classify_thread(self):
        if self.cls_combo.currentIndex() == 0:
            self.show_message_box('ClassifierError', QMessageBox.Critical, 'Please choose Classifier?')
        else:
            worker = Worker(self.classify_runner)
            self.thread_pool.start(worker)
            worker.signals.finished.connect(self.classify_finisher)
            self.load_screen.setWindowModality(Qt.ApplicationModal)
            self.load_screen.show()

    def classify_runner(self, progress_callback):
        resetRandom()
        cls = self.cls_combo.currentText()
        cls_path = os.path.join('classifiers', 'inception_v3_{0}.pkl'.format(cls))
        classifier = pickle.load(open(cls_path, 'rb'))
        import numpy as np
        pred = classifier.predict(np.array(self.feature, ndmin=2))[0]
        self.class_ = CLASS_NAMES[pred]
        progress_callback.emit('Done')

    def classify_finisher(self):
        self.add_image(self._input_image_path, 'Classified As {0}'.format(self.class_), f_size=True)
        self.class_ = None
        self.cls_combo.setEnabled(False)
        self.cls_pb.setEnabled(False)
        self.load_screen.close()

    def disable(self):
        self.ip_le.clear()
        self._input_image_path = ''
        self.ex_fe_pb.setEnabled(False)
        self.cls_combo.setEnabled(False)
        self.cls_combo.clear()
        self.cls_combo.addItems(['--Choose Classifier--', 'DecisionTreeClassifier', 'RandomForestClassifier'])
        self.cls_pb.setEnabled(False)

    def reset(self):
        self.disable()
        self.clear_layout(self.grid_2)


class Loading(QDialog):
    def __init__(self, parent=None):
        super(Loading, self).__init__(parent)
        self.screen_size = app.primaryScreen().size()
        self._width = int(self.screen_size.width() / 100) * 40
        self._height = int(self.screen_size.height() / 100) * 5
        self.setGeometry(0, 0, self._width, self._height)
        x = (self.screen_size.width() - self.width()) / 2
        y = (self.screen_size.height() - self.height()) / 2
        self.move(x, y)
        self.setWindowFlags(Qt.CustomizeWindowHint)
        self.pb = QProgressBar(self)
        self.pb.setFixedWidth(self.width())
        self.pb.setFixedHeight(self.height())
        self.pb.setRange(0, 0)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    th = Retinopathy()
    sys.exit(app.exec_())
