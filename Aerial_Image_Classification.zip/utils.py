import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import random
import tensorflow as tf
from tensorflow.python.keras import backend as k
import numpy as np
from PyQt5.QtCore import QObject, pyqtSignal, QRunnable, pyqtSlot
import traceback
import sys
import seaborn as sbn
from matplotlib import font_manager as fm
from matplotlib import pyplot as plt
prop = fm.FontProperties(fname='assets/fonts/FiraCode-Retina.ttf')
plt.rcParams['font.family'] = prop.get_name()
plt.rcParams['font.size'] = 14
plt.rcParams["figure.figsize"] = [19, 9]


CLASS_FOLDERS = [
    '00', '01', '02', '03', '04', '05', '06', '07', '08', '09',
    '10', '11', '12', '13', '14', '15', '16', '17', '18', '19',
    '20',
]

CLASS_NAMES = [
    'agricultural', 'airplane', 'baseballdiamond', 'beach', 'buildings', 'chaparral',
    'denseresidential', 'forest', 'freeway', 'golfcourse', 'harbor', 'intersection',
    'mediumresidential', 'mobilehomepark', 'overpass', 'parkinglot', 'river', 'runway',
    'sparseresidential', 'storagetanks', 'tenniscourt',
]


def resetRandom():
    seed = 1
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.compat.v1.random.set_random_seed(seed)
    session_conf = tf.compat.v1.ConfigProto(intra_op_parallelism_threads=1, inter_op_parallelism_threads=1)
    tf.compat.v1.set_random_seed(seed)
    sess = tf.compat.v1.Session(graph=tf.compat.v1.get_default_graph(), config=session_conf)
    k.set_session(sess)


def make_dirs(*dirs):
    for dir_ in dirs:
        os.makedirs(dir_, exist_ok=True)


def plot_conf_matrix(conf_mat, title, labels, path):
    plt.subplots(figsize=(19, 9))
    sbn.heatmap(conf_mat, annot=True, annot_kws={"size": 16}, linewidths=0.5, fmt='d',
                yticklabels=labels, xticklabels=labels, cmap='Blues')
    plt.xlabel('Predicted Class', labelpad=20)
    plt.ylabel('Actual Class', labelpad=20)
    plt.title(title, pad=20)
    plt.savefig(path, bbox_inches="tight")
    plt.close()
    plt.clf()


class WorkerSignals(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(tuple)
    result = pyqtSignal(object)
    progress = pyqtSignal(int)


class Worker(QRunnable):
    def __init__(self, fn, *args, **kwargs):
        super(Worker, self).__init__()

        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()

        self.kwargs['progress_callback'] = self.signals.progress

    @pyqtSlot()
    def run(self):
        try:
            result = self.fn(*self.args, **self.kwargs)
        except:
            traceback.print_exc()
            exctype, value = sys.exc_info()[:2]
            self.signals.error.emit((exctype, value, traceback.format_exc()))
        else:
            self.signals.result.emit(result)
        finally:
            self.signals.finished.emit()