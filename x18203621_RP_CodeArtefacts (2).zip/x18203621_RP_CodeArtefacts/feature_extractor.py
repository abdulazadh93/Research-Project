from utils import CLASS_NAMES, make_dirs, resetRandom
import tqdm
import glob
import os
import h5py
import numpy as np


#function to import Inception V3 layers
def get_inception_v3_model():
    from tensorflow.python.keras.applications.inception_v3 import InceptionV3
    from tensorflow.python.keras.models import Input
    model = InceptionV3(include_top=False,
                        weights='weights/inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5',
                        input_tensor=Input(shape=(299, 299, 3)))                 # Importing and pre-training the Inception V3 layers
    model.summary()                                                              # command to see the architecture of layers in network.
    return model


#function to defined the processing of image by the Inception V3 Layers.
def extract_feature(img_p, model):
    from tensorflow.python.keras.preprocessing import image
    from tensorflow.python.keras.applications.inception_v3 import preprocess_input
    size = (299, 299, 3)                                     # input dimension of the image
    img = image.load_img(img_p, target_size=size)            # re-size the input image to 299x299 RGB data.
    x = image.img_to_array(img)                              # image to array conversion
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)                                 # pre-processing the image file to suit the input layer of Inception V3 model.  
    feature = model.predict(x)                              # passing the image throught the layers for feature extraction.
    feat = feature.flatten()                                # flattening the features array.
    return feat


if __name__ == '__main__':
    resetRandom()
    data_path = 'Data/source/UCM'                           # datapath for dataset
    data_save_path = 'Data/features'                        # datapath to save extracted features
    make_dirs(data_save_path)                               # creating a new directory
    feats_dict = {'inception_v3_features': []}              # saving the features in variable
    labels = []                                             # empty array for labels
    iv3_model = get_inception_v3_model()      
    for cls in CLASS_NAMES:                                 # loop to import images from every land-use class from dataset.
        for img_path in tqdm.tqdm(glob.glob(os.path.join(data_path, cls, '*.tif')),
                                  desc=f'Extracting Features For Class {cls}'):
            feats_dict['inception_v3_features'].append(extract_feature(img_path, iv3_model))
            labels.append(CLASS_NAMES.index(cls))
    for k, v in feats_dict.items():                         # loop command to write the extracted features in HDF5 dataset file.
        if v:
            h5f_data = h5py.File(os.path.join(data_save_path, '{0}.h5'.format(k)), 'w')
            h5f_data.create_dataset('features', data=np.array(v))
            h5f_data.close()
            
    h5f_data = h5py.File(os.path.join(data_save_path, 'labels.h5'), 'w')       # appending the labels as a dataset in HDF5 file.
    h5f_data.create_dataset('labels', data=np.array(labels))
    h5f_data.close()
