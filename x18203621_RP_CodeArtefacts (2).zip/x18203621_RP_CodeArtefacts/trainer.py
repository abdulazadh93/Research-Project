import os
import pickle
import warnings

import h5py
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from utils import resetRandom, plot_conf_matrix, CLASS_NAMES

warnings.filterwarnings("ignore")

features = {
    'inception_v3': {
        'x': np.ndarray([]),
        'y': np.ndarray([]),
    }
}

#Dictionary of classifiers and their parameters.
classifiers = {
    'inception_v3': [
        DecisionTreeClassifier(max_leaf_nodes=360),
        RandomForestClassifier(n_estimators=10),
    ],
}

#directory to import features and labels.
features_dir = 'Data/features'

#directories created to store the classifiers and results.
classifier_dir = 'classifiers'
results_dir = 'results'
os.makedirs(classifier_dir, exist_ok=True)
os.makedirs(results_dir, exist_ok=True)

# looping features keys
for feature in features.keys():
    
    # reloading saved features from hdf5 file
    fe_path = os.path.join(features_dir, '{0}_{1}.h5'.format(feature, 'features'))
    feats = h5py.File(fe_path, 'r')
    fes = np.array(feats.get('features'))
    
    # reloading saved labels from hdf5 file
    lb_path = os.path.join(features_dir, 'labels.h5')
    labels = h5py.File(lb_path, 'r')
    lbs = np.array(labels.get('labels'))
    
    # store to features
    features[feature]['x'] = fes
    features[feature]['y'] = lbs

#dict to store performance measures
classifier_out = {'Feature': [], 'Classifier': [], 'Accuracy': [],
                  'Precision': [], 'Recall': [], 'F1-Score': []}


#looping features dict
for feature in list(features.keys()):
    x = features[feature]['x']
    y = features[feature]['y']
    train_x, test_x, train_y, test_y = train_test_split(x, y, test_size=0.2)
    print('[INFO] Train Data Shape :: {0} | Train Labels Shape :: {1}'.format(train_x.shape, train_y.shape))
    print('[INFO] Test Data Shape :: {0} | Test Labels Shape :: {1}'.format(test_x.shape, test_y.shape))
    
    # looping classifiers
    for classifier in classifiers[feature]:
        
        # resetting all random value generators by seed 1
        resetRandom()
        
        c_name = classifier.__class__.__name__
        classifier_path = os.path.join(classifier_dir, '{0}_{1}.pkl'.format(feature, c_name))
        print('[INFO] Feature :: {0} | Classifier :: {1}'.format(feature, c_name))
        # fitting x and y to train classifier
        classifier.fit(train_x, train_y)

# TRAINING DATASET
        train_pred = classifier.predict(train_x)
        
        # storing classification report
        train_res = classification_report(train_y, train_pred, output_dict=True)
        
        print('\tTraining Accuracy :: {0} %'.format(round(train_res['accuracy'] * 100, 2)))
        
        # storing confusion matrix
        train_cm = confusion_matrix(train_y, train_pred)
        print('\tTraining Confusion Matrix\n{0}'.format(train_cm))
        
        title = f'Features :: {feature} | Classifier :: {c_name}'
        plot_conf_matrix(train_cm, title, CLASS_NAMES, 'results/{0}_{1}.png'.format(feature, c_name))

# TEST DATASET
        test_pred = classifier.predict(test_x)
        
        # storing classification report
        test_res = classification_report(test_y, test_pred, output_dict=True)
        
        # storing confusion matrix
        test_cm = confusion_matrix(test_y, test_pred)
        print('\tTesting Confusion Matrix\n{0}'.format(test_cm))
        title = f'Features :: {feature} | Classifier :: {c_name}'
                
        print('\tSaving Classifier {0}'.format(classifier_path))
        
        # saving classifier to pickle file
        classifier_pkl = open(classifier_path, 'wb')
        pickle.dump(classifier, classifier_pkl)
        classifier_pkl.close()
        classifier_out['Feature'].append(feature)
        classifier_out['Classifier'].append(c_name)
        classifier_out['Accuracy'].append('{0}%'.format(
            round(train_res['accuracy'] * 100, 2)            
        ))
        classifier_out['Precision'].append('{0}%'.format(
            round(train_res['macro avg']['precision'] * 100, 2)
        ))
        classifier_out['Recall'].append('{0}'.format(
            round(train_res['macro avg']['recall'] * 100, 2)
        ))
        classifier_out['F1-Score'].append('{0}'.format(
            round(train_res['macro avg']['f1-score'] * 100, 2)
        ))

# saving performance measure to results.csv
pd.DataFrame.from_dict(classifier_out).to_csv('results/results.csv', index=False)
